classdef NexVariableTypes < double
    enumeration
        Neuron (0)
        Event (1)
        Interval (2)
        Waveform (3)
        Population (4)
        Continuous (5)
        Marker (6)
    end
end
