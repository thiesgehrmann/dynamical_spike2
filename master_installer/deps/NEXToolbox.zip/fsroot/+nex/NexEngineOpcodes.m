classdef NexEngineOpcodes
    properties (Constant = true)
        GetHeader = 1;
        GetEvents = 2;
        GetMarkers = 3;
        GetContinuous = 4;
        GetVariableHeaders = 5;
    end
end
